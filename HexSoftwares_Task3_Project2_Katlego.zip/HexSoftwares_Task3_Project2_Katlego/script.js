const books = [
    { id: 1, title: "Pride and Prejudice", author: "Jane Austen", category: "Fiction" },
    { id: 2, title: "1984", author: "George Orwell", category: "Fiction" },
    { id: 3, title: "Becoming", author: "Michelle Obama", category: "Non-Fiction" },
    { id: 4, title: "Educated", author: "Tara Westover", category: "Non-Fiction" },
    { id: 5, title: "The Catcher in the Rye", author: "J.D. Salinger", category: "Fiction" },
    { id: 6, title: "The Road to Character", author: "David Brooks", category: "Non-Fiction" },
    { id: 7, title: "The Hobbit", author: "J.R.R. Tolkien", category: "Fiction" },
    { id: 8, title: "Atomic Habits", author: "James Clear", category: "Non-Fiction" },
    { id: 9, title: "To Kill a Mockingbird", author: "Harper Lee", category: "Fiction" },
    { id: 10, title: "Becoming", author: "Michelle Obama", category: "Non-Fiction" },
  ];
  
  let borrowedBooks = JSON.parse(localStorage.getItem("borrowedBooks")) || [];

  function loadBooks(category = null) {
    const bookList = document.getElementById("bookList");
    bookList.innerHTML = "";
  
    const filteredBooks = category
      ? books.filter(book => book.category === category)
      : books;
  
    filteredBooks.forEach(book => {
      const bookCard = document.createElement("div");
      bookCard.className = "book-card";
      const isBorrowed = borrowedBooks.some(b => b.id === book.id);
  
      bookCard.innerHTML = `
        <h3>${book.title}</h3>
        <p><strong>Author:</strong> ${book.author}</p>
        <p><strong>Category:</strong> ${book.category}</p>
        <button ${isBorrowed ? "disabled" : ""} onclick="borrowBook(${book.id})">
          ${isBorrowed ? "Borrowed" : "Borrow"}
        </button>
      `;
      bookList.appendChild(bookCard);
    });
  }
  

  function borrowBook(id) {
    const book = books.find(b => b.id === id);
    const borrowDate = new Date().toLocaleDateString();
    borrowedBooks.push({ ...book, borrowDate });
    localStorage.setItem("borrowedBooks", JSON.stringify(borrowedBooks));
    alert(`${book.title} has been borrowed.`);
    loadBooks();
  }
  

  function loadHistory() {
    const historyList = document.getElementById("historyList");
    historyList.innerHTML = "";
  
    borrowedBooks.forEach((record, index) => {
      const div = document.createElement("div");
      div.className = "history-card";
      div.innerHTML = `
        <h3>${record.title}</h3>
        <p><strong>Author:</strong> ${record.author}</p>
        <p><strong>Borrowed On:</strong> ${record.borrowDate}</p>
        <button onclick="returnBook(${index})">Return</button>
      `;
      historyList.appendChild(div);
    });
  }
  

  function returnBook(index) {
    const returnedBook = borrowedBooks.splice(index, 1)[0];
    localStorage.setItem("borrowedBooks", JSON.stringify(borrowedBooks));
    alert(`${returnedBook.title} has been returned.`);
    loadHistory();
  }

  document.getElementById("searchBox")?.addEventListener("input", (e) => {
    const filter = e.target.value.toLowerCase();
    const filteredBooks = books.filter(book =>
      book.title.toLowerCase().includes(filter) || 
      book.author.toLowerCase().includes(filter)
    );
    displayBooks(filteredBooks);
  });
  

  document.addEventListener("DOMContentLoaded", () => {
    if (location.pathname.includes("fiction")) loadBooks("Fiction");
    else if (location.pathname.includes("non-fiction")) loadBooks("Non-Fiction");
    else if (location.pathname.includes("borrowing")) loadHistory();
    else loadBooks();
  });
  